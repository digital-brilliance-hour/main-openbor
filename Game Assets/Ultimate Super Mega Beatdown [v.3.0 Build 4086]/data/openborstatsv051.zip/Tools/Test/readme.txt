All default empty files will be contained here!

If you would like to add additional sets then edit the "Level.Txt" file contained in this directory.
If you have additional level design files then place them into the levels directory and follow the commands from the "Levels\readme.doc".

No other directories should be added here as they will not be used.